WITH quarterly_revenue AS (
    SELECT EXTRACT(YEAR FROM p.paid_date) AS year,
           EXTRACT(QUARTER FROM p.paid_date) AS quarter,
           SUM(p.amount) AS total_revenue
    FROM payments p
    JOIN completed_rides r ON p.ride_id = r.ride_id
    GROUP BY 1, 2
),
growth AS (
    SELECT year, quarter, total_revenue,
           LAG(total_revenue) OVER (PARTITION BY quarter ORDER BY year) AS prev_year_revenue,
           ROUND(
               100 * (total_revenue - LAG(total_revenue) OVER (PARTITION BY quarter ORDER BY year))
               / NULLIF(LAG(total_revenue) OVER (PARTITION BY quarter ORDER BY year), 0), 2
           ) AS yoy_growth_percent
    FROM quarterly_revenue
)
SELECT *
FROM growth
ORDER BY year, quarter;