SELECT r.rider_id, r.name, COUNT(cr.ride_id) AS total_rides
FROM riders r
JOIN completed_rides cr ON r.rider_id = cr.rider_id
LEFT JOIN payments p ON cr.ride_id = p.ride_id
GROUP BY r.rider_id, r.name
HAVING COUNT(cr.ride_id) > 10
   AND SUM(CASE WHEN LOWER(p.method) = 'cash' THEN 1 ELSE 0 END) = 0;
