
WITH city_revenue AS (
    SELECT r.pickup_city, r.driver_id, SUM(p.amount) AS total_revenue
    FROM completed_rides r
    JOIN payments p ON r.ride_id = p.ride_id
    GROUP BY r.pickup_city, r.driver_id
)
SELECT pickup_city, d.name AS driver_name, total_revenue
FROM (
    SELECT pickup_city, driver_id, total_revenue,
           ROW_NUMBER() OVER (PARTITION BY pickup_city ORDER BY total_revenue DESC) AS rn
    FROM city_revenue
) ranked
JOIN drivers d ON ranked.driver_id = d.driver_id
WHERE rn <= 3
ORDER BY pickup_city, total_revenue DESC;