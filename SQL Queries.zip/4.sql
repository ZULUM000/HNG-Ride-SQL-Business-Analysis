WITH driver_stats AS (
    SELECT r.driver_id,
           COUNT(*) AS total_rides,
           EXTRACT(MONTH FROM AGE(MAX(r.request_time), MIN(r.request_time))) + 1 AS active_months
    FROM completed_rides r
    GROUP BY r.driver_id
)
SELECT d.name AS driver_name,
       ROUND(total_rides::NUMERIC / NULLIF(active_months,0), 2) AS avg_rides_per_month
FROM driver_stats ds
JOIN drivers d ON ds.driver_id = d.driver_id
ORDER BY avg_rides_per_month DESC
LIMIT 5;