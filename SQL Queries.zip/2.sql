SELECT COUNT(DISTINCT r.rider_id) AS active_riders_2024
FROM riders r
JOIN completed_rides cr ON r.rider_id = cr.rider_id
WHERE EXTRACT(YEAR FROM r.signup_date) = 2021
  AND EXTRACT(YEAR FROM cr.request_time) = 2024;